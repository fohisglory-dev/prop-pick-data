// api/injuries.js
import { scrapeCBSInjuries } from '../lib/scrape.js';

export default async function handler(req, res) {
  try {
    const { league, team } = req.query;
    if (!league) {
      return res.status(400).json({ error: "Missing required query param 'league' (nba|nfl)" });
    }
    const data = await scrapeCBSInjuries(league, { team });
    return res.status(200).json({ ok: true, count: data.length, league: league.toLowerCase(), data });
  } catch (err) {
    return res.status(500).json({ ok: false, error: err.message });
  }
}
