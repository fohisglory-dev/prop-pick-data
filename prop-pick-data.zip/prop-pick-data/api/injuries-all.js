// api/injuries-all.js
import { scrapeCBSInjuries } from '../lib/scrape.js';

export default async function handler(req, res) {
  try {
    const leagues = (req.query.leagues || 'nba,nfl').split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
    const results = await Promise.all(leagues.map(lg => scrapeCBSInjuries(lg).catch(e => ({ error: e.message }))));
    const data = [];
    results.forEach((r, i) => {
      if (Array.isArray(r)) data.push(...r);
    });
    return res.status(200).json({ ok: true, count: data.length, leagues, data });
  } catch (err) {
    return res.status(500).json({ ok: false, error: err.message });
  }
}
